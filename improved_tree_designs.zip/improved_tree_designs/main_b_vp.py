from vp_tree_dynamic import VPTree
import numpy as np
from numpy import ndarray
import time
from tqdm import tqdm
import random
from typing import Dict, List, Tuple

def prepare_inputs(*args):
    """Converts the input points into a numpy array."""
    return [np.array(arg) for arg in args[0]]


def distance(point1:ndarray, point2:ndarray)->float:
        # Assumes the points are NumPy arrays and calculate the L2 distance
        return np.linalg.norm(point1 - point2)
    
def exhaustive_search(query:ndarray, point_lst:List)->Tuple:
    r_min = np.infty
    nn_pt = None
    #idx_min = 0
    for pt in point_lst:
        r = distance(pt, query)
        if r < r_min:
            nn_pt = pt
            r_min = r
            #idx_min = idx
    return r_min, nn_pt #, idx_min
    
def main():
    
    # Set the seed for reproducibility, 42
    random.seed(42)
    
    batch_size_1 = 300_000
    batch_size_2 = 500_000 - batch_size_1
    data_size = batch_size_1 + batch_size_2

    dim = 5
    rand_range = data_size 
    
    leaf_size_rebuild = 360
    epsilon_rebuild = 0.003
    
    epsilon_insert = 0.003
    
    print("Generating Points...")
    
    points = []
    # Directly generate a NumPy array of random points
    points = np.random.uniform(-rand_range, rand_range, size=(data_size, dim))
    
    vptree = VPTree(leaf_size=leaf_size_rebuild, epsilon=epsilon_rebuild)

    #* Build the tree
    print("Building Tree...")
    start_time = time.perf_counter()
    vptree.build(points=points[:batch_size_1])
    end_time = time.perf_counter()
    print(f"Build Time: {end_time-start_time:.6f}")

    query = [random.uniform(-1.0*rand_range,rand_range) for _ in range(dim)]
    
    query = prepare_inputs(query)
    print(f"Query: {query}")
    
    start_time = time.perf_counter()
    vptree.prepare_for_search()
    r_min, nn_pt = vptree.search(query)
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    print("-----------------------")
    print(f"Final r_min: {r_min}, nn_pt: {nn_pt}")
    print(f"VP Tree Search Time: {total_time:.6f} seconds")
    print("---------------------------")
    
    start_time = time.perf_counter()
    r_min_ex, nn_pt_ex = exhaustive_search(query=query, point_lst=points[:batch_size_1])
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    print(f"Exhaustive r_min: {r_min_ex}, nn_pt: {nn_pt_ex}")
    print(f"Exhaustive Search Time: {total_time:.6f} seconds")
    print("---------------------------")
    

    #* -- Insert the Second batch
    print("Preparing the Second Batch...")
    points_2 = prepare_inputs(points[batch_size_1:])
    points = prepare_inputs(points)

    #* Inserting Points
    print("Inserting Points...")
    
    vptree.epsilon = epsilon_insert
    
    for pt in tqdm(points_2):
        vptree.insert(pt)

    query = [random.uniform(-1.0*rand_range,rand_range) for _ in range(dim)]
    
    query = prepare_inputs(query)
    print(f"Query: {query}")
    
    start_time = time.perf_counter()
    vptree.prepare_for_search()
    r_min, nn_pt = vptree.search(query)
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    print("-----------------------")
    print(f"Final r_min: {r_min}, nn_pt: {nn_pt}")
    print(f"VP Tree Search Time: {total_time:.6f} seconds")
    print("---------------------------")
    
    start_time = time.perf_counter()
    r_min_ex, nn_pt_ex = exhaustive_search(query=query, point_lst=points)
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    print(f"Exhaustive r_min: {r_min_ex}, nn_pt: {nn_pt_ex}")
    print(f"Exhaustive Search Time: {total_time:.6f} seconds")
    print("---------------------------")
    
    
if __name__ == "__main__":
    main()