import numpy as np
from collections import deque
from quickselect import quickselect
from typing import List, Tuple, Union

#*-----------------------------------------------------------------------------
class KDNode:
    def __init__(self, points=None, left=None, right=None, parent=None):
        self.points = points if points is not None else []  # Now always a list of points
        self.split_dim = None
        self.split_val = None
        self.leaf = False
        self.left_tr = left
        self.right_tr = right
        self.parent = parent
        self.centroid = None
        self.radius = 0
        # NumPy array cache for search operations
        self._np_points = None

#*-----------------------------------------------------------------------------
class KDTree:
    def __init__(self, leaf_size=40, epsilon=0.1):
        self.points = None
        self.root = None
        self.dim = None
        self.leaf_size = leaf_size
        self.epsilon = epsilon

    #*-----------------------------------------------------------------------------
    
    def find_best_split_dimension(self, points: np.ndarray, start_dim: int) -> Tuple[int, bool]:
        # Simple round-robin dimension selection
        return start_dim, False

    #*-----------------------------------------------------------------------------

    def build(self, points):
        """
        KD-tree build aligned with the VP-tree pattern (no radius):
        • median via quickselect
        • epsilon band |x_d - median| < epsilon
        • keep up to leaf_size closest-to-median points ON THE NODE in node.points
        • children get the remaining points (<= median to left, > median to right), excluding kept band
        • leaves: node.leaf=True, node.points holds all leaf points, node.centroid is mean
        • internal nodes: node.leaf=False, node.points may hold band points; node.centroid is over those
        """
        if points is None or len(points) == 0:
            self.root = KDNode()
            return self.root

        self.points = points
        self.dim = points.shape[1]
        self.root = KDNode()

        # (node, pts, depth)
        stack = deque([(self.root, points, 0)])

        while stack:
            node, pts, depth = stack.pop()
            n = len(pts)

            # Leaf condition
            if n <= self.leaf_size:
                node.leaf = True
                node.points = pts.tolist()                  # list-of-points
                node.centroid = np.mean(pts, axis=0)        # mean over leaf points
                node._np_points = None                      # reset cache if you use it
                continue

            # Choose split dimension (your helper); pass depth % dim as a hint/cycle
            split_dim, all_equal = self.find_best_split_dimension(pts, depth % self.dim)

            # Degenerate: make a leaf
            if all_equal:
                node.leaf = True
                node.points = pts.tolist()
                node.centroid = np.mean(pts, axis=0)
                node._np_points = None
                continue

            node.split_dim = int(split_dim)

            # Median via quickselect over (value, idx)
            vals = pts[:, split_dim]
            coords = [(float(vals[i]), i) for i in range(n)]
            k = n // 2
            med_val, _ = quickselect(coords, k)             # returns (value, idx) tuple
            node.split_val = float(med_val)

            # Epsilon band: |x_d - median| < epsilon
            dev = np.abs(vals - node.split_val)
            band_mask = dev < self.epsilon
            band_idx = np.flatnonzero(band_mask)

            # Default binary masks (may be narrowed by excluding kept band points)
            left_mask = (vals <= node.split_val)
            right_mask = (vals >  node.split_val)

            if band_idx.size > 0:
                # Keep up to leaf_size closest-to-median from within band (no full sort)
                if band_idx.size > self.leaf_size:
                    dev_band = dev[band_idx]
                    sel = np.argpartition(dev_band, self.leaf_size - 1)[:self.leaf_size]
                    keep_idx = band_idx[sel]
                else:
                    keep_idx = band_idx

                # Store band points directly in node.points (internal "stash")
                thr_arr = pts[keep_idx]
                node.points = [p for p in thr_arr]          # list for consistency
                node.centroid = thr_arr.mean(axis=0)        # centroid over stored band points
                node._np_points = None

                # Exclude kept band points from children
                keep_mask = np.zeros(n, dtype=bool)
                keep_mask[keep_idx] = True
                left_mask = (vals <= node.split_val) & (~keep_mask)
                right_mask = (vals >  node.split_val) & (~keep_mask)
            else:
                # No band kept on this node
                node.points = []                            # keep internal nodes empty if nothing kept
                node.centroid = None
                node._np_points = None

            # Partition for children
            left_pts = pts[left_mask]
            right_pts = pts[right_mask]

            if left_pts.size > 0:
                node.left_tr = KDNode(parent=node)
                stack.appendleft((node.left_tr, left_pts, depth + 1))
            if right_pts.size > 0:
                node.right_tr = KDNode(parent=node)
                stack.appendleft((node.right_tr, right_pts, depth + 1))

        return self.root

    #*-----------------------------------------------------------------------------

    def insert(self, point: Union[List, np.ndarray]):
        """
        KD-tree insert consistent with the KD build that:
        • uses strict epsilon band: abs(x_d - split_val) < epsilon
        • stores up to leaf_size band points on INTERNAL nodes in node.points
        • updates node.centroid over stored band points
        • otherwise routes by <= split_val to left, > split_val to right
        • leaves: append to node.points and update centroid
        • no radius anywhere; reset _np_points cache when mutating node.points
        """
        if isinstance(point, list):
            point = np.asarray(point, dtype=float)

        # Empty tree → create a leaf root
        if self.root is None:
            self.dim = len(point)
            self.root = KDNode()
            self.root.points = [point]
            self.root.centroid = point
            self.root.leaf = True
            self.root._np_points = None
            return

        current = self.root

        # Traverse until a leaf, as internal nodes may store band points in node.points
        while not current.leaf:
            # Safety: if an internal node lacks split info, make it a leaf (shouldn't happen after build)
            if current.split_dim is None:
                current.points = [point]
                current.centroid = point
                current.leaf = True
                current._np_points = None
                return

            d = current.split_dim
            m = current.split_val
            v = float(point[d])

            # Strict epsilon band (matches build dev < epsilon)
            if abs(v - m) < self.epsilon:
                # Initialize internal-node stash
                if not current.points:
                    current.points = [point]
                    current.centroid = point
                    current._np_points = None
                    return
                # Keep up to leaf_size band points at this internal node
                if len(current.points) < self.leaf_size:
                    n = len(current.points)
                    c_old = current.centroid
                    current.points.append(point)
                    current.centroid = (n * c_old + point) / (n + 1)
                    current._np_points = None
                    return
                # Band full → fall through to routing

            # Route exactly like build's partition outside the (strict) band: <= left, > right
            if v <= m:
                if current.left_tr is None:
                    current.left_tr = KDNode(parent=current)
                    current = current.left_tr
                    current.points = [point]
                    current.centroid = point
                    current.leaf = True
                    current._np_points = None
                    return
                current = current.left_tr
            else:
                if current.right_tr is None:
                    current.right_tr = KDNode(parent=current)
                    current = current.right_tr
                    current.points = [point]
                    current.centroid = point
                    current.leaf = True
                    current._np_points = None
                    return
                current = current.right_tr

        # Reached a leaf: append and update centroid
        n = len(current.points)

        # Optional: homogeneous storage adjustment (mirrors VP insert behavior)
        if n == 2 * self.leaf_size:
            self.leaf_size = n

        c_old = current.centroid
        current.points.append(point)
        current.centroid = (n * c_old + point) / (n + 1)
        current._np_points = None

    #*-----------------------------------------------------------------------------
    def prepare_for_search(self):
        """
        Convert all list-based collections to numpy arrays for efficient search.
        Also computes exact radius for each node's stored points.

        This should be called once after all insertions and before searches.
        """
        stack = [self.root]
        while stack:
            node = stack.pop()
            if node is None:
                continue

            # Convert points to NumPy array and compute radius
            if node.points:
                node._np_points = np.array(node.points)
                if len(node.points) > 1:
                    diffs = node._np_points - node.centroid
                    node.radius = float(np.sqrt(np.sum(diffs * diffs, axis=1)).max())
                else:
                    node.radius = 0.0
            else:
                node._np_points = None
                node.radius = 0.0

            # Add children to stack
            if node.left_tr:
                stack.append(node.left_tr)
            if node.right_tr:
                stack.append(node.right_tr)

    #*-----------------------------------------------------------------------------
    def search(self, query):
        """
        KD-tree NN search (assumes prepare_for_search() has been called):
        • For any node with a bucket (_np_points not None), prune by ||q-c|| - r.
        • Route like build: <= split_val -> left, > split_val -> right.
        • Hyperplane prune: visit 'far' only if |q[d] - split_val| < best_dist.
        • No array creation here.
        """
        if self.root is None:
            return float("inf"), None

        q = np.asarray(query, dtype=float)
        best_dist = float("inf")
        best_point = None

        stack = [self.root]
        while stack:
            node = stack.pop()
            if node is None:
                continue

            # Evaluate node's bucket (leaf or internal epsilon-band)
            P = node._np_points
            if P is not None and P.size > 0:
                dc = np.linalg.norm(q - node.centroid)
                if dc - node.radius < best_dist:
                    dists = np.linalg.norm(P - q, axis=1)
                    i = int(np.argmin(dists))
                    di = dists[i]
                    if di < best_dist:
                        best_dist = di
                        best_point = P[i]

            # Leaf: no children
            if node.leaf:
                continue

            # Internal: route + hyperplane pruning
            d = node.split_dim
            m = node.split_val
            if d is None:
                continue

            diff = q[d] - m
            if diff <= 0.0:
                near, far = node.left_tr, node.right_tr
            else:
                near, far = node.right_tr, node.left_tr

            if far is not None and abs(diff) < best_dist:
                stack.append(far)
            if near is not None:
                stack.append(near)

        return best_dist, best_point
#*-----------------------------------------------------------------------------